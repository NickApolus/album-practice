<?php
session_start();
require_once 'config/connect.php';
$photos = $_GET['id'];

$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$photosShow = mysqli_query($link, "SELECT * from `photos` WHERE `idPhoto` = '$photos' ");//количество строк
$getTitle = mysqli_query($link, "SELECT * from `album` WHERE `id` = '$photos' ");
if ($link == false) {
    print ("Ошибка: Невозможно подключиться к MySQL " . mysqli_connect_error());
} else {
    // print ("Соединение установлено успешно");
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Album</title>
    <link href="styles/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">
    <link rel="stylesheet" href="styles/normalize.css">
    <link rel="stylesheet" href="styles/modal.css">
</head>
<body>
<?php  require_once 'templates/header.php';  ?>
<!-- modal -->
<!-- Button trigger modal -->

<div  class="main-flex-modal btn-dangerous">
<div class="modal-w">
<p align="right" size="24" class="clo">x&nbsp;</p>

    <div  class="modal-w-body">
        <div class="madal-w-img" ><p style="margin-top: 10px;" align="center"><img style="border-radius: 8px;" width="600" height="380" id="myModalView" src="" alt=""></p></div>
    </div>
</div>
</div>
<!--  modal -->
<?php $crum = mysqli_fetch_assoc($getTitle) ?>
    <div class="container">
    <div class="bread-crums">
        <p><a href="/">Главная / </a></p>
        <p class="onIt">&nbsp;<?php echo $crum['title']; ?></p>
    </div>
        <div class="flex-container">
            <?php while ($photo = mysqli_fetch_assoc($photosShow)) { 
                
                // Выводит количество комментариев

                $soThatSumCom =  $photo['id']; 
                $sql = "SELECT COUNT(*) FROM comments WHERE idPhoto = '$soThatSumCom'  ";


                $arrayCount = mysqli_fetch_assoc(mysqli_query($link, $sql));

                $count = $arrayCount['COUNT(*)'];
            ?>
                <div class="item">
                    <!-- 1 -->

                    <div class="item-flex">
                        <div class="item-flex-picture"><img id="" onclick="showPhotoSrc(event)" class="photo" src="<?php echo $photo['way'] ?>" alt="photo"></div>
                        <div class="btns-like-dislike">
                            <div class="like icon-com">
                                <p class="com-light btn1" style="cursor:pointer; margin-left: 5px;"><a href="comments.php?id=<?php echo $photo['id'] ?>"><span style="color: black;">&nbsp;
                            <?php
                            
                                echo $count;

                            ?>
                            
                            </span><img src="sistem-images/comment.png" alt=""></a></p>
                            </div>
                            <div class="like icon">
                                <!-- форма отправки лайка -->
                                <form method="POST" action="action/like-func/dolike.php?id=<?php echo $photo['id']?>">
                                    <button style="background-color: bisque; border: 0px solid black;"   type="submit" name="action" value="like"><img width="20px" height="20px" src="sistem-images/like.png" alt="">&nbsp;<?php echo $photo['likes'] ?></button>
                                    <button  style="background-color: bisque; border: 0px solid black;"  type="submit" name="action" value="dislike"><img width="20px" height="20px" src="sistem-images/dislike.png" alt="">&nbsp;<?php echo $photo['dislikes'] ?></button>
                                </form>

                            </div>
                        </div>
                        <hr>
                        <details class="fff">
                            <summary class="msg">дополнительные действия над фото</summary>
                            <div class="block-msg">
                                <a class="btn btn-danger" href="action/delete-photo.php?id=<?=$photo['id']?>">х</a><span class="msg-inside"> Удалить, Вы уверены?</span>
                            </div>
                        </details>
                    </div>
                </div>
            <?php } ?>

                 
        </div>
    </div>
     <!-- ============================================================================form============================================================================ -->    
     <p align="center" class="mt-4">
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <b>Добавить фото</b>
        </button>
    </p>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Добавить фото</h1>
                    <button id="clean" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="form-add" class="form-add" action="action/create-photo.php" method="post" enctype="multipart/form-data">
                        <p>Название фото</p>
                        <input id="myInput1"  class="form-control form-control-sm" type="text" placeholder="Введите название"
                            aria-label=".form-control-sm example" name="title" required>
                        <br>
                        <p>Выберите файл</p>
                        <br>
                        <label  class="form-control" for="">Выберите png, jpeg, jpg</label>
                        <input id="myInput2" accept=".jpg, .jpeg, .png" type="file" name="file" class="form-control" required>
                        <br>
                        <input  class="form-control form-control-sm" type="hidden" name="idPhoto" value="<?php echo $photos ?>"
                            aria-label=".form-control-sm example" required>
                        <button disabled id="btn-save" type="submit" class="btn btn-success">Добавить</button>
                    </form>
                </div>
                <!-- <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                </div> -->
            </div>
        </div>
    </div>
    <script src="scripts/bootstrap.bundle.min.js"></script>           
    <script src="scripts/app.js"></script>
</body>
</html>
