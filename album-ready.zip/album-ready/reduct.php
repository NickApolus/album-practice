<?php
require_once 'config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$reductAlbum = $_GET['id'];
$result = mysqli_query($link, "SELECT * FROM album WHERE `id` = '$reductAlbum' ");
$reduct = mysqli_fetch_assoc($result);// скок вывод 
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <title>Редактирование альбома</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Альбом главная</title>
    <link rel="stylesheet" href="styles/normalize.css">
    <link href="styles/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/reduct.css">
</head>
<body>
    <?php  require_once 'templates/header.php';  ?>
    <div class="container mt-4">
        <p><a href="/">Главная&nbsp;/</a><span class="onIt">&nbsp;Cтраница редактирования альбом</span></p>
        <br>
        <br>
        <h1>Редактирование альбома &#9998; <span><img src="<?= $reduct['preview'] ?>" alt="" width="300" height="250"></span></h1>
        <div class="wrapper">
            <form id="form-add" action="action/update.php" method="post" enctype="multipart/form-data">
                <input class="form-control form-control-sm" type="hidden" name="id" value="<?= $reduct['id'] ?>" required>
                <br>
                <p>Название альбома</p>
                <input class="form-control" type="text" name="title" value="<?= $reduct['title'] ?>" required>
                <br>
                <p>Описание альбома</p>
                <textarea class="form-control" name="description" required><?= $reduct['description'] ?></textarea>
                <br>
                <p>Заглавная картинка</p>
                <input accept=".jpg, .jpeg, .png" value="<?= $reduct['preview'] ?>" type="file" name="file" class="form-control" required>
                <br>
                <button disabled id="btn-save" type="submit" class="btn btn-warning">Исправить</button>
            </form>
        </div>
    </div>
    <script src="scripts/app.js"></script> 
</body>
</html>