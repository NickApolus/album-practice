<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/connect.php';

$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if ($link == false) {
    print ("ошибка подключения к MySQL " . mysqli_connect_error());
} else {
    // echo "<p>Соединение с БД успешное!</p>";
}
mysqli_set_charset($link, "utf8");

$takePhoto = $_GET['id'];

// echo "my var".  $takePhoto;

$takeComment = mysqli_query($link, "SELECT * from `comments` WHERE `idPhoto` = '$takePhoto' ");
$takePhotoDetail = mysqli_query($link, "SELECT * from `photos` WHERE `id` = '$takePhoto' ");
if (!$takeComment) {
    die('Ошибка выполнения запроса: ' . mysqli_error($link));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="styles/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles/com.css">
    <link rel="stylesheet" href="styles/normalize.css">

</head>

<body>

    <?php require_once 'templates/header.php'; ?>

    <div class="container mt-4">
        <?php while ($photo = mysqli_fetch_assoc($takePhotoDetail)) { ?>
        <p><a href="/">Главная&nbsp;/ </a><a href="photos.php?id=<?php echo $photo['idPhoto']?>">Вернуться к альбому /</a><span class="onIt">&nbsp;Комментарии</span></p>
        
            <div class="img">
                <img src="<?php echo $photo['way'] ?>" alt="">
            </div>
            <h5 align="center"><?php echo $photo['title'] ?></h5>
        <?php } ?>
    </div>

    <br>
    <br>


    <div class="wrapper-flex">
        <h3>&#9998; Комментарии:</h3>
        <br>
        <?php while ($comment = mysqli_fetch_assoc($takeComment)) { ?>
            <div style="display: flex; gap: 20px; align-items: center; width: 40%;">
                <div class="ava"><img width="55" height="55" src="sistem-images/ava2.png" alt=""><span>Гость</span><br><span
                        style="font-size: 9px;"><?php #echo $comment['data'] ?></span></div>
                <div class="text">
                    <p
                        style="font-size: 12px; border: 0px solid white; background-color: white; padding: 10px; border-radius: 8px; min-width: 450px; color: black;">
                        <?php echo $comment['body'] ?>
                        <br>
                        <p style="font-size: 9px;" align="right"><?php echo $comment['data'] ?></p>
                    </p>
                </div>
            </div>
        <?php } ?>
    </div>

    <div class="container">
        <div class="col-6">
            <form id="form-add"  action="action/com-leave.php" method="post">
                <input class="form-control form-control-sm" type="hidden" name="idPhotography"
                    value="<?php echo $takePhoto ?>" required>
                <br>
                <p>Ваш комментарий</p>
                <textarea type="text" class="form-control" name="text-comment"
                    placeholder="Введите Ваш комментарий" required></textarea>
                <br>
                <button id="btn-save" disabled type="submit" class="btn btn-warning">отправить</button>
            </form>
        </div>
    </div>
    <script src="scripts/app.js"></script>      
</body>

</html>