<?php
echo '<!-- Just an image -->
<nav class="navbar navbar-light bg-dark">
        <a class="cvet" href="#" >
        &nbsp;Альбом
        </a>
</nav>'
?>