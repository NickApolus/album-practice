let btns = document.querySelectorAll('.btn1');
let clos = document.querySelectorAll('.clo');
let btnWarning = document.querySelector('.btn-dangerous');
var screen = document.getElementById("myModalView");


// Получаем все элементы с классом "photo"
var photos = document.getElementsByClassName("photo");

// Добавляем обработчик события к каждой фотографии
for (var i = 0; i < photos.length; i++) {
    photos[i].addEventListener("click", showPhotoSrc);
}

function showPhotoSrc(event) {
    var clickedPhoto = event.target; 
    var photoSrc = clickedPhoto.src; 
    screen.src = photoSrc;
    btnWarning.classList.add('shown');
}

// Закрытие

for(clo of clos){
    clo.addEventListener('click' , function(event){
    btnWarning.classList.remove('shown');    
        console.log(2);
    });
}

// =======================================================
// Валидация формы album.php

const form = document.getElementById("form-add");
const formSubmit = document.getElementById("btn-save");



form.addEventListener('change', changeFormHandler);

function changeFormHandler() {
  console.log(form.checkValidity());
  if (form.checkValidity()) {
    
    formSubmit.removeAttribute('disabled');
  }
}


// Очистить инпуты при закрытии формы

let btnClean = document.getElementById("clean");

let input1 = document.getElementById("myInput1");
let input2 = document.getElementById("myInput2");
let input3 = document.getElementById("myInput3");

btnClean.addEventListener('click', function(){
  input1.value = '';
  input2.value = '';
  input3.value = '';
})



