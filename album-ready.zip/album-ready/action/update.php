<?php
require_once '../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$id = $_POST['id'];
$title = $_POST['title'];
$description = $_POST['description'];
$changeImg;
if (!empty($_FILES['file']['name'])) {
    move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . '/images/' . $_FILES['file']['name']);
    if ($_FILES['file']['type'] == "image/png") {
        $changeImg = '../sistem-images/nophoto.jpg';
    }
    var_dump($_FILES['file']['type']);
    if ($_FILES['file']['type'] == "image/jpeg" || $_FILES['file']['type'] == "image/jpg" ){
        $changeImg = 'images/' . $_FILES['file']['name'];
        var_dump("hello");
    }
}
mysqli_query($link, "UPDATE `album` SET `title`='$title',`preview`='$changeImg',`description`='$description' WHERE `id` = '$id'");
header('location: ../album.php');


?>