<?php
require_once '../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$id = $_GET['id'];
$getId = mysqli_query($link, "SELECT * from photos WHERE id = '$id'" );
if (!$getId) {
    $message  = 'Неверный запрос: '  . "\n";
    $message .= 'Запрос целиком: ' . $query;
    die($message);
}
$foo = mysqli_fetch_assoc($getId);
$ourId = $foo['idPhoto'];
$idPhoto; 
mysqli_query($link, "DELETE FROM photos WHERE id = '$id'");
mysqli_query($link, "DELETE FROM comments WHERE idPhoto = '$id'");
header('location: ../photos.php?id='.$ourId);
?>