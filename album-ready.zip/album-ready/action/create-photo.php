<?php 
require_once '../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$titlePhoto = $_POST['title'];
$idPhoto = $_POST['idPhoto'];

$nravica = 0;
$nenravica = 0;

$img;
if (!empty($_FILES['file']['name'])) {
    move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . '/images/' . $_FILES['file']['name']);
    if ($_FILES['file']['type'] == "image/png") {
        $img = 'sistem-images/nophoto.jpg';
    }
    var_dump($_FILES['file']['type']);
    if ($_FILES['file']['type'] == "image/jpeg" || $_FILES['file']['type'] == "image/jpg" ){
        $img = 'images/' . $_FILES['file']['name'];
        var_dump("hello");
    }
}
mysqli_query($link, "INSERT INTO `photos` (`id`, `title`, `way`, `likes`,`dislikes`, `idPhoto`) VALUES (null, '$titlePhoto','$img' , '$nravica', '$nenravica', '$idPhoto');");
header('location: ../photos.php?id='.$idPhoto);