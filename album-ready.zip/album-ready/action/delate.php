<?php
require_once '../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$id = $_GET['id'];
mysqli_query($link, "DELETE FROM album WHERE id = '$id'");
mysqli_query($link, "DELETE FROM photos WHERE idPhoto = '$id'");
header('location: ../album.php');
?>