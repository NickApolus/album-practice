<?php
require_once '../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$id = $_POST['id'];
$title = $_POST['title'];
$description = $_POST['description'];
// ========================================создание файла===================================================
$picture = $_FILES['file']['name'];

// Найти расширение

$arrNameAndExt = explode(".", $picture);  //разить имя файла на имя и его расширение

 $endFile = end($arrNameAndExt);

// главная проверка
if($endFile=='jpg'||$endFile=='jpeg'||$endFile=='svg'||$endFile=='gif'||$endFile=='png'){

//var_dump($_FILES['file']['name'] . "<br>" . $_FILES['file']['tmp_name'] . "<br>" . $_FILES['file']['type'] );
if (!empty($_FILES['file']['name'])) {
    move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . '/images/' . $_FILES['file']['name']);
    // var_dump('check the file'.move_uploaded_file($_FILES['file']['tmp_name']));
    if ($_FILES['file']['type'] == "image/png") {
        $picture = 'images/' . $_FILES['file']['name'];
        mysqli_query($link, "INSERT INTO `album` (`id`, `title`, `description`, `preview`) VALUES (null, '$title', '$description', '$picture');");
        header('location: ../album.php');
    }
    if ($_FILES['file']['type'] == "image/jpeg" || $_FILES['file']['type'] == "image/jpg" ){
        $picture = 'images/' . $_FILES['file']['name'];
        mysqli_query($link, "INSERT INTO `album` (`id`, `title`, `description`, `preview`) VALUES (null, '$title', '$description', '$picture');");
        header('location: ../album.php');
    }
    // else{
    //     header('location: ../album.php');
        
    // }
}

}

else{
    header('location: ../album.php');
}

?>


