<?php 
session_start();

require_once '../../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

$albumMine;
// Код лайков

echo 'check the id of album!'. $albumMine;

// $photo_id = intval($_GET['photo_id']); // Получаем ID фотографии
$photo_id = $_GET['id'];

echo 'проверка'. $photo_id . "<br>";
// Код лайков
// Проверяем, установлен ли photo_id
if (!isset($_GET['id'])) {
    die("Photo ID is required");
}
// Инициализация сессионных переменных, если они не установлены
if (!isset($_SESSION['vote'][$photo_id])) {
    $_SESSION['vote'][$photo_id] = null; // null - ни лайк, ни дизлайк
}

// Обработка действия пользователя
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    // Получение текущих лайков и дизлайков из базы данных для указанной фотографии
    $sql = "SELECT likes, dislikes, idPhoto FROM photos WHERE id=$photo_id";
    $result = mysqli_query($link, $sql);

    if (mysqli_num_rows($result) == 0) {
        // Если записи для данной фотографии нет, создаем её
        $sql = "INSERT INTO photos (id, likes, dislikes) VALUES ($photo_id, 0, 0)";
        mysqli_query($link, $sql);
        $likes = 0;
        $dislikes = 0;
        $row = mysqli_fetch_assoc($result);
        $albumMine = $row['idPhoto'];	
        
    } else {
        $row = mysqli_fetch_assoc($result);
        $likes = $row['likes'];
        $dislikes = $row['dislikes'];
        $albumMine = $row['idPhoto'];
    }

    if ($action === 'like') {
        if ($_SESSION['vote'][$photo_id] === 'dislike') {
            // Удаляем дизлайк и добавляем лайк
            $dislikes--;
            $likes++;
            $_SESSION['vote'][$photo_id] = 'like';
        } elseif ($_SESSION['vote'][$photo_id] === 'like') {
            // Убираем лайк
            $likes--;
            $_SESSION['vote'][$photo_id] = null;
        } else {
            // Добавляем лайк
            $likes++;
            $_SESSION['vote'][$photo_id] = 'like';
        }
    } elseif ($action === 'dislike') {
        if ($_SESSION['vote'][$photo_id] === 'like') {
            // Удаляем лайк и добавляем дизлайк
            $likes--;
            $dislikes++;
            $_SESSION['vote'][$photo_id] = 'dislike';
        } elseif ($_SESSION['vote'][$photo_id] === 'dislike') {
            // Убираем дизлайк
            $dislikes--;
            $_SESSION['vote'][$photo_id] = null;
        } else {
            // Добавляем дизлайк
            $dislikes++;
            $_SESSION['vote'][$photo_id] = 'dislike';
        }

        // $idThisPhoto = $row['idPhoto'];
    }

    // Обновление базы данных с новыми значениями лайков и дизлайков
    $sql = "UPDATE photos SET likes=$likes, dislikes=$dislikes WHERE id=$photo_id";
    mysqli_query($link, $sql);
}

mysqli_close($link );

header('location: ../../photos.php?id=' . $albumMine);