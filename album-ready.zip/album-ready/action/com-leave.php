<?php 
require_once '../config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

$idPhoto = $_POST['idPhotography'];



var_dump($idPhoto);

$textComment = $_POST['text-comment'];

$current_time = date("Y-m-d H:i:s");

if($textComment != ''){
    var_dump($textComment);

    mysqli_query($link, "INSERT INTO `comments` (`id`, `body`,`data`,`idPhoto` ) VALUES (null, '$textComment', '$current_time' ,'$idPhoto');");
    header('location: ../comments.php?id=' . $idPhoto);
}
else{
    header('location: ../comments.php?id=' . $idPhoto);
}


// Возвращаюсь к фото с комментариями




