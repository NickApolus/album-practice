-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 26 2024 г., 22:53
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gallery`
--

-- --------------------------------------------------------

--
-- Структура таблицы `album`
--

CREATE TABLE `album` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `preview` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `album`
--

INSERT INTO `album` (`id`, `title`, `description`, `preview`) VALUES
(93, 'Много амфибий', 'У свеце шмат рэптылій. Ручныя і небяспечныя для кантакту з чалавекам', 'images/hamelion.jpg'),
(94, 'Коты', 'Разнообразные кошки', 'images/cat.jpg'),
(128, 'Велосипеды', 'Этот альбом посвящен велоспорту', 'images/withbmx.jpg'),
(149, 'Собаки', 'Разные породы', 'images/dog2.jpg'),
(150, 'Рыбы пресных водоёмов ', 'В водоёмах Белоруси встречаются', 'images/okun.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `body` text NOT NULL,
  `data` timestamp NOT NULL,
  `idPhoto` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `body`, `data`, `idPhoto`) VALUES
(1, 'Вот это да , какое интересное фото представилось мне видеть сейчас ', '2024-05-25 12:19:20', 33),
(27, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2024-05-25 15:06:55', 54),
(29, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2024-05-25 15:07:48', 52),
(30, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2024-05-25 15:19:06', 33),
(31, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2024-05-25 15:19:11', 33),
(33, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2024-05-25 15:37:59', 33),
(34, 'asdadaasa', '2024-05-25 16:56:33', 37),
(35, 'Варан ', '2024-05-25 17:56:40', 33),
(36, 'Черепаха ', '2024-05-25 17:58:58', 62),
(43, 'Ящерица', '2024-05-26 13:01:39', 37),
(44, 'bigiiuguiguiguiuibgi', '2024-05-26 18:14:10', 37),
(45, 'Бесстрашная, выносливая и храбрая порода, представители которой получили множество наград, заслуживают звания самой лучшей породы собак как сторожевых, так и домашних. Собаку лучше всего приобретать в младенческом возрасте.', '2024-05-26 19:33:30', 80),
(46, 'Это дружелюбные, добрые собаки, любящие всех и каждого. Они социально адаптированы и могут хорошо общаться с другими животными и детьми. Они терпеливы и готовы многое прощать, но никогда не следует этим злоупотреблять. Лабрадоры крайне преданны и любят участвовать во всех семейных делах.', '2024-05-26 19:34:01', 79);

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

CREATE TABLE `photos` (
  `id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `way` varchar(255) NOT NULL,
  `likes` int DEFAULT NULL,
  `dislikes` int DEFAULT NULL,
  `idPhoto` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `title`, `way`, `likes`, `dislikes`, `idPhoto`) VALUES
(12, 'lizard ', 'images/lizard.jpg', NULL, NULL, 1),
(20, 'яшчарка ', 'images/lizard.jpg', NULL, NULL, 3),
(21, 'сабака злы', 'images/dog.jpg', NULL, NULL, 2),
(22, 'toy', 'images/cat.jpg', NULL, NULL, 84),
(23, '', 'images/hamelion.jpg', NULL, NULL, 1),
(24, 'dragon', 'images/dragon.jpg', NULL, NULL, 1),
(25, '', 'images/varan.jpg', NULL, NULL, 1),
(26, '', 'images/turtle.jpg', NULL, NULL, 1),
(27, 'snake', 'images/snake.jpg', NULL, NULL, 1),
(29, 'cat', 'images/cat.jpg', NULL, NULL, 89),
(30, 'lizard', 'images/lizard.jpg', NULL, NULL, 90),
(31, 'dog', 'images/dog.jpg', NULL, NULL, 91),
(33, 'Varan', 'images/varan.jpg', 1, 4, 93),
(37, 'lizard', 'images/lizard.jpg', 1, 2, 93),
(41, 'Абясінскае кацяннё', 'images/abesinsk-cat.jpg', NULL, NULL, 92),
(42, 'Мэйн кун', 'images/mainkun.jpg', NULL, NULL, 92),
(43, 'Лясны кот', 'images/wild-cat.jpg', NULL, NULL, 92),
(51, 'Кошка Гены', 'images/wild-cat.jpg', 25, 63, 94),
(52, 'Кошка Сашы', 'images/forest-cat.jpg', 11, 18, 94),
(53, 'Кот большой', 'images/cat.jpg', 13, 11, 94),
(54, 'Snake-big', 'images/dragon.jpg', 22, 30, 93),
(62, 'Turtle', 'images/turtle.jpg', 2, 0, 93),
(70, 'Бэмикс', 'images/bmx1.jpg', 1, 0, 128),
(71, 'бэм', 'images/bunny.jpg', 1, 0, 128),
(72, 'так', 'images/withbmx.jpg', 1, 0, 128),
(73, 'Сиамский', 'images/abesinsk-cat.jpg', 1, 0, 94),
(74, 'Египетская кошка ', 'images/egipt-cat.jpg', 1, 0, 94),
(75, 'Сиамец', 'images/seam-cat.jpg', 1, 0, 94),
(76, 'Порода кота', 'images/veslo-cat.jpg', 1, 0, 94),
(77, 'Мейнкун', 'images/mainkun.jpg', 1, 0, 94),
(79, 'Лабрадор', 'images/dog.jpg', 1, 0, 149),
(80, 'Овчарка', 'images/dog2.jpg', 1, 0, 149),
(81, 'рыба1', 'images/ryba.jpg', 0, 0, 150),
(82, 'рыба1', 'images/karas.jpg', 0, 0, 150);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `album`
--
ALTER TABLE `album`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT для таблицы `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
