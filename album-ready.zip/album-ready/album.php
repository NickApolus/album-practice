<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config/connect.php';
$link = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if ($link == false) {
    print ("ошибка подключения к MySQL " . mysqli_connect_error());
} else {
    // echo "<p>Соединение с БД успешное!</p>";
}
mysqli_set_charset($link, "utf8");
$result = mysqli_query($link, 'SELECT * from `album`');
?>
<!DOCTYPE html>
<lang="ru">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Альбом главная</title>
        <link href="styles/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="styles/home.css">
        <link rel="stylesheet" href="styles/normalize.css">
    </head>
    <?php require_once 'templates/header.php'; ?>
    <div class="container">
        <div class="flex-block flex-plus">
            <!-- ITEM -->
            <?php while ($album = mysqli_fetch_assoc($result)) { ?>
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo $album['preview'] ?>" class="card-img-top" alt="" width="">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $album['title'] ?></h5>
                        <p class="card-text"><?php echo $album['description'] ?></p>
                        <div class="kirunak">
                            <a href="photos.php?id=<?= $album['id'] ?>" class="btn btn-primary">Просмотр</a>
                            <a href="reduct.php?id=<?= $album['id'] ?>" class="btn btn-success">Редактировать</a>
                        </div>
                    </div>
                    <hr>
                    <details class="detail1">
                        <summary class="msg-before"><span class="msg-before-ins">Удалить</span> целый альбом?</summary>
                        <p class="uvaga btn1"><a href="action/delate.php?id=<?= $album['id'] ?>"
                                class="btn btn-danger">удалить</a><img src="sistem-images/delete.png" alt="" width="16"
                                height="16"></p>
                    </details>
                </div>
            <?php } ?>
        </div>
    </div>
    <!-- Modal -->
    <p align="center" class="mt-4">
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <b>Добавить альбом</b>
        </button>
    </p>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Добавить альбом</h1>
                    <button id="clean" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="form-add" id="form-add" action="action/create.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id">
                        <p>Название</p>
                        <input id="myInput1" class="form-control form-control-sm" type="text"
                            placeholder="Введите название" aria-label=".form-control-sm example" name="title" required>
                        <br>
                        <textarea id="myInput2" class="form-control form-control-sm" name="description"
                            placeholder="Введите описание" aria-label=".form-control-sm example" required></textarea>
                        <br>
                        <p>Установить обои для альбома</p>
                        <br>
                        <label  class="form-control" for="">Выберите png, jpeg, jpg</label>
                        <input id="myInput3"   accept=".jpg, .jpeg, .png" type="file" name="file" class="form-control" required>
                        <br>
                        <button disabled id="btn-save" type="submit" class="btn btn-success">Добавить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <script src="scripts/app.js"></script>
    <script src="scripts/bootstrap.bundle.min.js"></script>
    </body>

    </html>